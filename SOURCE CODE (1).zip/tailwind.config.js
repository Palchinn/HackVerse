/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        whitesmoke: "#f4f4f4",
        seagreen: "#3a6e51",
        dimgray: "#785e3d",
        peru: "#bf7f30",
        white: "#fff",
        black: "#000",
        darkkhaki: "#b3a843",
        snow: "#fffcfc",
        gainsboro: { "100": "#d9d9d9", "200": "rgba(225, 225, 225, 0.06)" },
        mistyrose: "#efe1e1",
        steelblue: "#3b6993",
      },
      fontFamily: {
        inter: "Inter",
        "im-fell-french-canon": "'IM FELL French Canon'",
        saira: "Saira",
        "ibm-plex-sans-condensed": "'IBM Plex Sans Condensed'",
        sanchez: "Sanchez",
        "font-awesome-5-free": "'Font Awesome 5 Free'",
        "jockey-one": "'Jockey One'",
      },
      borderRadius: { "3xs": "10px", "31xl": "50px" },
    },
    fontSize: { "3xs": "10px", base: "16px", "2xs": "11px" },
  },
  corePlugins: { preflight: false },
};
