const Desktop1 = () => {
  return (
    <div className="relative bg-whitesmoke w-full h-[887px] overflow-hidden text-left text-3xs text-white font-inter">
      <div className="absolute top-[0px] left-[0px] w-[583px] h-[394px]" />
      <img
        className="absolute top-[0px] left-[0px] rounded-t-none rounded-br-[20px] rounded-bl-none w-[579px] h-[332px] object-cover"
        alt=""
        src="/rectangle-2@2x.png"
      />
      <div className="absolute top-[7px] left-[13px] text-base font-jockey-one inline-block w-[87px] h-4 [-webkit-text-stroke:1px_#000]">
        SOURC3 COD3
      </div>
      <div className="absolute top-[16px] left-[343px] w-[70px] h-[18px] font-font-awesome-5-free">
        <div className="absolute top-[2px] left-[58.05px] inline-block w-[11.95px]">
          
        </div>
        <div className="absolute top-[0px] left-[0px] text-2xs font-saira inline-block w-[68.29px] h-[18px]">
          Categories
        </div>
      </div>
      <div className="absolute top-[17px] left-[418px] w-[49px] h-[18px] text-2xs font-saira">
        <div className="absolute top-[0px] left-[0px] inline-block w-[49px] h-[18px]">
          Activity
        </div>
        <div className="absolute top-[2px] left-[41px] text-[12px] font-font-awesome-5-free">
          
        </div>
      </div>
      <div className="absolute top-[16px] left-[188px] w-[70px] h-2.5 text-2xs font-saira">
        <div className="absolute top-[0px] left-[0px] inline-block w-[70px] h-2.5">
          New Arrivals
        </div>
      </div>
      <div className="absolute top-[16px] left-[119px] w-[76px] h-[18px] text-2xs font-saira">
        <div className="absolute top-[0px] left-[0px] inline-block w-[76px] h-[18px]">
          Best Sellers
        </div>
      </div>
      <div className="absolute top-[37px] left-[491px] rounded-31xl bg-black w-[73px] h-4 hidden" />
      <button
        className="[border:none] p-0 bg-[transparent] absolute top-[16px] left-[485px] w-[79px] h-[19px]"
        disabled
      >
        <img
          className="absolute top-[0px] left-[-4px] rounded-31xl w-[79px] h-[27px]"
          alt=""
          src="/rectangle-5.svg"
        />
        <div className="absolute top-[3px] left-[19px] text-2xs font-sanchez text-white text-left inline-block w-[60px] h-4">
          Wallet
        </div>
      </button>
      <div className="absolute top-[79px] left-[27px] text-[36px] capitalize font-im-fell-french-canon inline-block w-[230px] h-[49px]">
        Place where designers are Sellers.
      </div>
      <button className="cursor-pointer [border:none] p-0 bg-steelblue absolute top-[236px] left-[49px] rounded-31xl w-[70px] h-[27px]" />
      <div className="absolute top-[242px] left-[62px] text-2xs capitalize font-ibm-plex-sans-condensed text-mistyrose inline-block w-[47px] h-[19px]">
        EXPLORE
      </div>
      <button className="cursor-pointer p-0 bg-gainsboro-100 absolute top-[235px] left-[141px] rounded-31xl shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)_inset] box-border w-[70px] h-[30px] border-[1px] border-solid border-black" />
      <div className="absolute top-[242px] left-[164px] text-2xs font-ibm-plex-sans-condensed text-black inline-block w-12 h-4">
        SELL
      </div>
      <div className="absolute top-[16px] left-[263px] text-2xs font-saira inline-block w-20 h-[13px]">
        Free Designs
      </div>
      <div className="absolute top-[392px] left-[25px] rounded-3xs bg-peru w-[108px] h-[129px]" />
      <div className="absolute top-[498px] left-[31px] inline-block w-[46px] h-[11px]">
        Creator 1
      </div>
      <div className="absolute top-[392px] left-[167px] rounded-3xs bg-peru w-[108px] h-[129px]" />
      <div className="absolute top-[521px] left-[171px] text-gainsboro-200 inline-block w-[46px] h-[11px]">
        Creator 2
      </div>
      <div className="absolute top-[392px] left-[306px] rounded-3xs bg-peru w-[108px] h-[129px]" />
      <div className="absolute top-[392px] left-[448px] rounded-3xs bg-peru w-[108px] h-[129px]" />
      <div className="absolute top-[396px] left-[29px] rounded-t-3xs rounded-b-none bg-white w-[100px] h-[94px]" />
      <div className="absolute top-[396px] left-[171px] rounded-t-3xs rounded-b-none bg-white w-[100px] h-[94px]" />
      <div className="absolute top-[396px] left-[310px] rounded-t-3xs rounded-b-none bg-white w-[100px] h-[94px]" />
      <div className="absolute top-[396px] left-[452px] rounded-t-3xs rounded-b-none bg-white w-[100px] h-[94px]" />
      <img
        className="absolute top-[409px] left-[171px] w-[100px] h-[68px] object-cover"
        alt=""
        src="/1000-f-479831529-hzgb40snbpxcrana97yoxhsvkugn1hgqtransformed-1@2x.png"
      />
      <div className="absolute top-[498px] left-[105px] inline-block w-[23px] h-2">
        $10
      </div>
      <div className="absolute top-[498px] left-[171px] inline-block w-[46px] h-[11px]">
        Creator 2
      </div>
      <div className="absolute top-[498px] left-[249px] inline-block w-[23px] h-2">
        $25
      </div>
      <div className="absolute top-[498px] left-[455px] inline-block w-[46px] h-[11px]">
        Creator 4
      </div>
      <div className="absolute top-[498px] left-[529px] inline-block w-[23px] h-2">
        $18
      </div>
      <div className="absolute top-[498px] left-[31px] inline-block w-[46px] h-[11px]">
        Creator 1
      </div>
      <div className="absolute top-[498px] left-[313px] inline-block w-[46px] h-[11px]">
        Creator 3
      </div>
      <div className="absolute top-[498px] left-[391px] inline-block w-[23px] h-2">
        $16
      </div>
      <img
        className="absolute h-[calc(100%_-_796px)] top-[401px] bottom-[395px] left-[31px] rounded-t-3xs rounded-b-none max-h-full w-[95px] object-cover"
        alt=""
        src="/stockvectorallviewsmenswhiteshortsleevepoloshirtdesigntemplatesfrontbackhalfturnedandside178284005transformed-1@2x.png"
      />
      <div className="absolute top-[746px] left-[25px] rounded-3xs bg-dimgray w-[170px] h-[105px]" />
      <div className="absolute top-[751px] left-[29px] rounded-tl-3xs rounded-tr-none rounded-b-3xs bg-white w-[100px] h-[94px]" />
      <img
        className="absolute top-[402px] left-[310px] w-[98px] h-[84px] object-cover"
        alt=""
        src="/240-f-379460310-tv7oobvu3m5usicxpya2j282cescupoe-1@2x.png"
      />
      <div className="absolute top-[353px] left-[17px] text-base font-im-fell-french-canon text-black inline-block w-[217px] h-6">
        LIVE AUCTIONS
      </div>
      <img
        className="absolute top-[398px] left-[456px] w-[90px] h-[91.09px] object-cover"
        alt=""
        src="/1000-f-549364031-qflrqkpvuftklhwi72zkkrtfn62lqnjytransformed-1@2x.png"
      />
      <div className="absolute top-[592px] left-[32px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[119px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[119px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[206px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[206px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[293px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[293px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[380px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[380px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[467px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[592px] left-[467px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <div className="absolute top-[553px] left-[17px] text-base font-im-fell-french-canon text-black inline-block w-[222px] h-[34px]">
        TOP CREATORS
      </div>
      <img
        className="absolute top-[585px] left-[31px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e535637d87131637b0e4379-peep39-1.svg"
      />
      <img
        className="absolute top-[585px] left-[118px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e5350f9d399238698511b2f-peep7-1.svg"
      />
      <img
        className="absolute top-[585px] left-[205px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e5350dd2b568a1afd157d3d-peep6-1.svg"
      />
      <img
        className="absolute top-[585px] left-[292px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e5358707371bb635d9f3338-peep58-1.svg"
      />
      <div className="absolute top-[660px] left-[293px] text-black text-center inline-block w-[60px] h-[11px]">
        Flore Tour
      </div>
      <div className="absolute top-[660px] left-[380px] text-black text-center inline-block w-[60px] h-[11px]">
        Juel Sin
      </div>
      <div className="absolute top-[660px] left-[467px] text-black text-center inline-block w-[60px] h-[11px]">
        Tobi Grant
      </div>
      <img
        className="absolute top-[585px] left-[379px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e532a4c258ffe237b8ef2c1-peep2-1.svg"
      />
      <img
        className="absolute top-[585px] left-[467px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e53510f2b568ad72715a304-peep8-1.svg"
      />
      <div className="absolute top-[660px] left-[33px] text-black text-center inline-block w-[60px] h-[11px]">
        Kritsen Gig
      </div>
      <div className="absolute top-[592px] left-[32px] rounded-3xs bg-seagreen w-[60px] h-[65px]" />
      <img
        className="absolute top-[585px] left-[31px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e535637d87131637b0e4379-peep39-1.svg"
      />
      <div className="absolute top-[833px] left-[127px] text-right inline-block w-[60px] h-[11px]">
        Kritsen Gig
      </div>
      <div className="absolute top-[767px] left-[129px] rounded-tl-none rounded-tr-3xs rounded-br-3xs rounded-bl-none bg-darkkhaki w-[60px] h-[65px]" />
      <img
        className="absolute top-[760px] left-[128px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e535637d87131637b0e4379-peep39-3.svg"
      />
      <div className="absolute top-[660px] left-[205px] text-black text-center inline-block w-[60px] h-[11px]">
        Tina miles
      </div>
      <textarea
        className="[border:none] bg-[transparent] font-inter text-3xs absolute top-[754px] left-[131px] text-white text-left inline-block w-[60px] h-[11px]"
        placeholder="$24"
      />
      <div className="absolute top-[660px] left-[119px] text-black text-center inline-block w-[60px] h-[11px]">
        Ricky Wong
      </div>
      <img
        className="absolute top-[760px] left-[29px] rounded-3xs w-[100px] h-[79px] object-cover"
        alt=""
        src="/1000-f-365172149-riab7by8tzmrzkll4gdhpzpdml3yhvjztransformed-1@2x.png"
      />
      <div className="absolute top-[746px] left-[207px] rounded-3xs bg-dimgray w-[170px] h-[105px]" />
      <div className="absolute top-[751px] left-[211px] rounded-tl-3xs rounded-tr-none rounded-b-3xs bg-white w-[100px] h-[94px]" />
      <div className="absolute top-[746px] left-[390px] rounded-3xs bg-dimgray w-[170px] h-[105px]" />
      <div className="absolute top-[751px] left-[394px] rounded-tl-3xs rounded-tr-none rounded-b-3xs bg-white w-[100px] h-[94px]" />
      <img
        className="absolute top-[770px] left-[211px] w-[100px] h-[53.4px] object-cover"
        alt=""
        src="/1000-f-553430004-ze4wxiiltxpv45lbqol4v6tibfj4irbstransformed-1@2x.png"
      />
      <div className="absolute top-[767px] left-[312px] rounded-tl-none rounded-tr-3xs rounded-br-3xs rounded-bl-none bg-darkkhaki w-[60px] h-[65px]" />
      <img
        className="absolute top-[760px] left-[311px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e5350dd2b568a1afd157d3d-peep6-2.svg"
      />
      <div className="absolute top-[833px] left-[308px] text-snow text-right inline-block w-[60px] h-[11px]">
        Tina miles
      </div>
      <img
        className="absolute top-[759px] left-[494px] w-[60px] h-20 overflow-hidden"
        alt=""
        src="/5e535637d87131637b0e4379-peep39-4.svg"
      />
      <div className="absolute top-[833px] left-[494px] text-right inline-block w-[60px] h-[11px]">
        Kritsen Gig
      </div>
      <div className="absolute top-[767px] left-[495px] rounded-tl-none rounded-tr-3xs rounded-br-3xs rounded-bl-none bg-darkkhaki w-[60px] h-[65px]" />
      <div className="absolute top-[760px] left-[494px] w-[60px] h-20">
        <img
          className="absolute h-[74.79%] w-[68%] top-[13.24%] right-[15.98%] bottom-[11.97%] left-[16.02%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/introduction.svg"
        />
        <textarea
          className="[border:none] bg-[transparent] font-inter text-3xs absolute h-[13.75%] w-full top-[-7.5%] left-[5%] text-white text-left inline-block"
          placeholder="$30"
        />
      </div>
      <div className="absolute top-[710px] left-[17px] text-base font-im-fell-french-canon text-black inline-block w-[147px] h-[23px]">
        TOP PICKS
      </div>
      <textarea
        className="[border:none] bg-[transparent] font-inter text-3xs absolute top-[754px] left-[314px] text-white text-left inline-block w-[60px] h-[11px]"
        placeholder="$15"
      />
      <div className="absolute top-[751.25px] left-[128.75px] box-border w-[54.5px] h-[0.5px] border-t-[0.5px] border-solid border-white" />
      <div className="absolute top-[751.25px] left-[309.75px] box-border w-[54.5px] h-[0.5px] border-t-[0.5px] border-solid border-white" />
      <div className="absolute top-[751.25px] left-[494.75px] box-border w-[54.5px] h-[0.5px] border-t-[0.5px] border-solid border-white" />
      <div className="absolute top-[383.5px] left-[566.5px] box-border w-px h-36 border-r-[1px] border-solid border-peru" />
      <div className="absolute top-[732.5px] left-[566.5px] box-border w-px h-[129px] border-r-[1px] border-solid border-dimgray" />
      <div className="absolute top-[582.5px] left-[566.5px] box-border w-px h-[91px] border-r-[1px] border-solid border-seagreen" />
      <img
        className="absolute top-[753px] left-[405px] w-[76.54px] h-[92px] object-cover"
        alt=""
        src="/1000-f-479825511-zft9zkfhbo5qamvj0dkwxrpdskqdkfkvtransformed-1@2x.png"
      />
    </div>
  );
};

export default Desktop1;
